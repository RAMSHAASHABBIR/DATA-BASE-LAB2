﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBLab1Hometask
{
    public partial class AddC : Form
    {
        public AddC()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) &&
                !string.IsNullOrWhiteSpace(textBox3.Text) && !string.IsNullOrWhiteSpace(textBox4.Text))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Courses VALUES (@Course_ID, @Course_Name, @Teacher_Name, @Semester)", con);
                cmd.Parameters.AddWithValue("@Course_ID", textBox1.Text);
                cmd.Parameters.AddWithValue("@Course_Name", textBox2.Text);
                cmd.Parameters.AddWithValue("@Teacher_Name", textBox3.Text);
                cmd.Parameters.AddWithValue("@Semester", textBox4.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
            }
            else
            {
                MessageBox.Show("Please enter valid values.");
                con?.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cources c = new Cources();
            c.Show();
            this.Close();
        }
    }
}
