﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab1Hometask
{
    public partial class Search : Form
    {
        public Search()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string registrationNumberToSearch = textBox1.Text.Trim();
            if (!string.IsNullOrEmpty(registrationNumberToSearch))
            {
                var con = Configuration.getInstance().getConnection();
                int count = -1;
                string query = "SELECT COUNT(*) FROM Student WHERE RegistrationNumber = @RegNumber";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@RegNumber", registrationNumberToSearch);
                    con.Close();
                    con.Open();
                    object result = cmd.ExecuteScalar();
                    if (int.TryParse(result.ToString(), out count))
                    {
                        if (count > 0)
                        {
                            MessageBox.Show("Course found!");
                        }
                        else
                        {
                            MessageBox.Show("Course not found.");
                        }
                    }
                }
                con.Close();
            }
            else
            {
                MessageBox.Show("Please enter a registration number for search.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cources c = new Cources();
            c.Show();
            this.Hide();
        }
    }
}
