﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab1Hometask
{
    public partial class Student : Form
    {
        public Student()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddS add = new AddS();
            add.Show();
            this.Hide();

        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReadDel readDel = new ReadDel();
            readDel.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Search search = new Search();
            search.Show();
            this.Hide();

        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
