﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab1Hometask
{
    public partial class SearchCourse : Form
    {
        public SearchCourse()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string Course_IDToSearch = textBox1.Text.Trim();
            if (!string.IsNullOrEmpty(Course_IDToSearch))
            {
                var con = Configuration.getInstance().getConnection();
                int count = -1;
                string query = "SELECT COUNT(*) FROM Courses WHERE Course_ID = @Course_ID";
                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@Course_ID", Course_IDToSearch);
                    con.Close();
                    con.Open();
                    object result = cmd.ExecuteScalar();
                    if (int.TryParse(result.ToString(), out count))
                    {
                        if (count > 0)
                        {
                            MessageBox.Show("Student found!");
                        }
                        else
                        {
                            MessageBox.Show("Student not found.");
                        }
                    }
                }
                con.Close();
            }
            else
            {
                MessageBox.Show("Please enter a Course_ID for search.");
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cources c = new Cources();
            c.Show();
            this.Hide();
        }
    }
}
