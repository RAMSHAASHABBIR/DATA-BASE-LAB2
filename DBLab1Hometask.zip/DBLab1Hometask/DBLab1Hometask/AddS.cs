﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab1Hometask
{
    public partial class AddS : Form
    {
        public AddS()
        {
            InitializeComponent();
        }
        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();

            if (!string.IsNullOrWhiteSpace(textBox1.Text) && !string.IsNullOrWhiteSpace(textBox2.Text) &&
                !string.IsNullOrWhiteSpace(textBox3.Text) && int.TryParse(textBox4.Text, out int session) &&
                 !string.IsNullOrWhiteSpace(textBox5.Text))
            {
                SqlCommand cmd = new SqlCommand("INSERT INTO Student VALUES (@RegNumber, @Name, @Department, @Session, @Address)", con);
                cmd.Parameters.AddWithValue("@RegNumber", textBox1.Text);
                cmd.Parameters.AddWithValue("@Name", textBox2.Text);
                cmd.Parameters.AddWithValue("@Department", textBox3.Text);
                cmd.Parameters.AddWithValue("@Session", session);
                cmd.Parameters.AddWithValue("@Address", textBox5.Text);
                cmd.ExecuteNonQuery();
                MessageBox.Show("Successfully saved");
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear();
                textBox4.Clear();
                textBox5.Clear();
            }
            else
            {
                MessageBox.Show("Please enter valid values.");
                con?.Close();
            }
        }
        private void button2_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student.Show();
            this.Close();
        }
    }
}
