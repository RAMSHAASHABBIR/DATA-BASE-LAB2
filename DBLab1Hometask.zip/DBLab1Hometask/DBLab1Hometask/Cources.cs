﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab1Hometask
{
    public partial class Cources : Form
    {
        public Cources()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddC add = new AddC();
            add.Show();
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            ReadDelUpCourse read = new ReadDelUpCourse();
            read .Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Search s = new Search();
            s.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form1 form = new Form1();
            form.Show();
            this.Hide();
        }
    }
}
