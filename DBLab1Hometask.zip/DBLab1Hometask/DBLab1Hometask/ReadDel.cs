﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBLab1Hometask
{
    public partial class ReadDel : Form
    {
        public ReadDel()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student.Show();
            this.Close();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                DialogResult result = MessageBox.Show("Do you want to delete this record?", "Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("DELETE FROM Student WHERE RegistrationNumber = @RegNumber", con);
                    cmd.Parameters.AddWithValue("@RegNumber", selectedRow.Cells["RegistrationNumber"].Value.ToString());
                    cmd.ExecuteNonQuery();
                    con.Close();
                    dataGridView1.Rows.Remove(selectedRow);
                    MessageBox.Show("Record successfully deleted");
                    con.Open();
                }
            }
            else
            {
                MessageBox.Show("Please select a single row to delete");
            }
        }
        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                textBox1.Text = selectedRow.Cells["RegistrationNumber"].Value?.ToString();
                textBox2.Text = selectedRow.Cells["Name"].Value?.ToString();
                textBox3.Text = selectedRow.Cells["Department"].Value?.ToString();
                textBox4.Text = selectedRow.Cells["Session"].Value?.ToString();
                textBox5.Text = selectedRow.Cells["Address"].Value?.ToString();
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                label5.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                textBox5.Visible = true;
                button5.Visible = true;
            }
            else
            {
                MessageBox.Show("Please select a single row to delete");
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) &&
           !string.IsNullOrWhiteSpace(textBox2.Text) &&
           !string.IsNullOrWhiteSpace(textBox3.Text) &&
            int.TryParse(textBox4.Text, out int updatedSession) &&
           !string.IsNullOrWhiteSpace(textBox5.Text))
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("UPDATE Student SET Name = @Name, Department = @Department, Session = @Session, Address = @Address WHERE RegistrationNumber = @RegNumber", con);
                cmd.Parameters.AddWithValue("@RegNumber", textBox1.Text);
                cmd.Parameters.AddWithValue("@Name", textBox2.Text);
                cmd.Parameters.AddWithValue("@Department", textBox3.Text);
                cmd.Parameters.AddWithValue("@Session", updatedSession);
                cmd.Parameters.AddWithValue("@Address", textBox5.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                label1.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                label5.Visible = false;
                textBox1.Visible = false;
                textBox2.Visible = false;
                textBox3.Visible = false;
                textBox4.Visible = false;
                textBox5.Visible = false;
                button5.Visible = false;
                MessageBox.Show("Updated successfully");
                con.Open();
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter valid values.");
            }
        }
    }

}

