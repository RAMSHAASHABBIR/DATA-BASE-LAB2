﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace DBLab1Hometask
{
    public partial class ReadDelUpCourse : Form
    {
        public ReadDelUpCourse()
        {
            InitializeComponent();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Courses", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                DialogResult result = MessageBox.Show("Do you want to delete this record?", "Confirmation",
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    var con = Configuration.getInstance().getConnection();
                    SqlCommand cmd = new SqlCommand("DELETE FROM courses WHERE course_ID = @Course_ID", con);
                    cmd.Parameters.AddWithValue("@Course_ID", selectedRow.Cells["course_ID"].Value.ToString());
                    cmd.ExecuteNonQuery();
                    con.Close();
                    dataGridView1.Rows.Remove(selectedRow);
                    MessageBox.Show("Record successfully deleted");
                    con.Open();
                }
            }
            else
            {
                MessageBox.Show("Please select a single row to delete");
            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            Cources c = new Cources();
            c.Show();
            this.Close();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                textBox1.Text = selectedRow.Cells["Course_ID"].Value?.ToString();
                textBox2.Text = selectedRow.Cells["Course_Name"].Value?.ToString();
                textBox3.Text = selectedRow.Cells["Teacher_Name"].Value?.ToString();
                textBox4.Text = selectedRow.Cells["Semester"].Value?.ToString();
                label1.Visible = true;
                label2.Visible = true;
                label3.Visible = true;
                label4.Visible = true;
                textBox1.Visible = true;
                textBox2.Visible = true;
                textBox3.Visible = true;
                textBox4.Visible = true;
                button5.Visible = true;
            }
            else
            {
                MessageBox.Show("Please select a single row to delete");
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(textBox1.Text) &&
                !string.IsNullOrWhiteSpace(textBox2.Text) &&
                !string.IsNullOrWhiteSpace(textBox3.Text) &&
                !string.IsNullOrWhiteSpace(textBox4.Text))
            {
                var con = Configuration.getInstance().getConnection();
                SqlCommand cmd = new SqlCommand("UPDATE Courses SET course_Name = @Course_Name, teacher_Name = @Teacher_Name, semester = @Semester WHERE course_ID = @Course_ID", con);
                cmd.Parameters.AddWithValue("@Course_ID", textBox1.Text);
                cmd.Parameters.AddWithValue("@Course_Name", textBox2.Text);
                cmd.Parameters.AddWithValue("@Teacher_Name", textBox3.Text);
                cmd.Parameters.AddWithValue("@Semester", textBox4.Text);
                cmd.ExecuteNonQuery();
                con.Close();
                label1.Visible = false;
                label2.Visible = false;
                label3.Visible = false;
                label4.Visible = false;
                textBox1.Visible = false;
                textBox2.Visible = false;
                textBox3.Visible = false;
                textBox4.Visible = false;
                button5.Visible = false;
                MessageBox.Show("Updated successfully");
            }
            else
            {
                MessageBox.Show("Invalid input. Please enter valid values.");
            }

        }
    }
}
