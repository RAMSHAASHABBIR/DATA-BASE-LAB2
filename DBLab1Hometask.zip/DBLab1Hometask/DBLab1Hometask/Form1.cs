﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab1Hometask
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Student student = new Student();
            student.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Cources cources = new Cources();
            cources.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Enrollment enrollment = new Enrollment();
            enrollment.Show();
            this.Hide();

        }
    }
}
