﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace DBLab1Hometask
{
    public partial class Enrollment : Form
    {
        public Enrollment()
        {
            InitializeComponent();
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Student", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView1.DataSource = dt;
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var con = Configuration.getInstance().getConnection();
            SqlCommand cmd = new SqlCommand("Select * from Courses", con);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            dataGridView2.DataSource = dt;
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form1 f = new Form1();
            f.Show();
            this.Hide();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1 && dataGridView2.SelectedRows.Count == 1)
            {
                DataGridViewRow selectedRow = dataGridView1.SelectedRows[0];
                string studentRegno = selectedRow.Cells["RegistrationNumber"].Value?.ToString();
                string courseName = dataGridView2.SelectedRows[0].Cells["Course_Name"].Value.ToString();
                var con = Configuration.getInstance().getConnection();
                SqlCommand checkCmd = new SqlCommand("SELECT COUNT(*) FROM Enrollments WHERE StudentRegNo = @StudentRegNo AND CourseName = @CourseName", con);
                checkCmd.Parameters.AddWithValue("@StudentRegNo", studentRegno);
                checkCmd.Parameters.AddWithValue("@CourseName", courseName);
                int existingCount = (int)checkCmd.ExecuteScalar();
                if (existingCount > 0)
                {
                    MessageBox.Show($"Student '{studentRegno}' is already registered for course '{courseName}'.");
                }
                else
                {
                    SqlCommand cmd = new SqlCommand("INSERT INTO Enrollments (StudentRegNo, CourseName) VALUES (@StudentRegNo, @CourseName)", con);
                    cmd.Parameters.AddWithValue("@StudentRegNo", studentRegno);
                    cmd.Parameters.AddWithValue("@CourseName", courseName);
                    cmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show($"Student '{studentRegno}' registered for course '{courseName}'.");
                    con.Open();
                }
            }
            else
            {
                MessageBox.Show("Please select a student and a course to register.");
            }
        }
        private void button5_Click(object sender, EventArgs e)
        {
            if (dataGridView1.SelectedRows.Count == 1 && dataGridView2.SelectedRows.Count == 1)
            {
                string studentRegno = dataGridView1.SelectedRows[0].Cells["RegistrationNumber"].Value?.ToString();
                string courseName = dataGridView2.SelectedRows[0].Cells["Course_Name"].Value.ToString();
                var con = Configuration.getInstance().getConnection();
                string checkQuery = "SELECT COUNT(*) FROM Enrollments WHERE StudentRegNo = @StudentRegNo AND CourseName = @CourseName";
                SqlCommand checkCmd = new SqlCommand(checkQuery, con);
                checkCmd.Parameters.AddWithValue("@StudentRegNo", studentRegno);
                checkCmd.Parameters.AddWithValue("@CourseName", courseName);
                int count = Convert.ToInt32(checkCmd.ExecuteScalar());
                if (count > 0)
                {
                    string deleteQuery = "DELETE FROM Enrollments WHERE StudentRegNo = @StudentRegNo AND CourseName = @CourseName";
                    SqlCommand deleteCmd = new SqlCommand(deleteQuery, con);
                    deleteCmd.Parameters.AddWithValue("@StudentRegNo", studentRegno);
                    deleteCmd.Parameters.AddWithValue("@CourseName", courseName);
                    deleteCmd.ExecuteNonQuery();
                    con.Close();
                    MessageBox.Show($"Student '{studentRegno}' unregistered from course '{courseName}'");
                    con.Open();
                }
                else
                {
                    MessageBox.Show($"Student '{studentRegno}' is not enrolled in course '{courseName}'");
                }
            }
            else
            {
                MessageBox.Show("Please select a student and a course to unregister.");
            }

        }
    }
}
